package com.wangyan.test;


import org.junit.Test;

import com.wangyan.utils.XMLAnalyser;

public class TestXMLAnalyser {
	@Test
	public void testName() throws Exception {
		
		XMLAnalyser xmlAnalyser = new XMLAnalyser();
		System.out.println("111111111111111");
		xmlAnalyser.analyseOSM();
	}
	
}
